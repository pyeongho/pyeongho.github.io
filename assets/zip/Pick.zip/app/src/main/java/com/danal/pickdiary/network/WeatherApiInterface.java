package com.danal.pickdiary.network;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by phkim on 2017-02-14.
 */

public interface WeatherApiInterface {
    @Headers({"Accept: application/json"})
    @POST(".")
    Call<WeatherRepo> get_Weather_retrofit();
}
