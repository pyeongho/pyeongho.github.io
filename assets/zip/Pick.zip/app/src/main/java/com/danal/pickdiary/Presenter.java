package com.danal.pickdiary;

import android.view.View;

/**
 * Created by phkim on 2017-02-14.
 */

public interface Presenter {
    void setView(MyView view);
    void onInfoRequest();
}
