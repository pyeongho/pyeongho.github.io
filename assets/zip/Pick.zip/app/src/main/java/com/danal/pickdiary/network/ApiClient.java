package com.danal.pickdiary.network;

import android.util.Log;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by phkim on 2017-02-14.
 */

public class ApiClient {
    public void getWeather(){
        Log.e("aaaa","날씨정보 불러오기 실패 :"  );
        Retrofit client = new Retrofit.Builder().baseUrl("https://demo-project-revolt9w.c9users.io").addConverterFactory(
            GsonConverterFactory.create()).build();
        WeatherApiInterface service = client.create(WeatherApiInterface.class);
        Call<WeatherRepo> call = service.get_Weather_retrofit();
        call.enqueue(new Callback<WeatherRepo>() {
            @Override
            public void onResponse(Call<WeatherRepo> call, Response<WeatherRepo> response) {
                Log.e("aaaa","날씨정보 불러오기 실패 :"+response.message()  );
                if(response.isSuccessful()){
                    WeatherRepo weatherRepo = response.body();

                    if(weatherRepo.getResult().getCode().equals("9200")){ // 9200 = 성공
                        Log.e("aaaa",weatherRepo.getResult().getMessage());
                        return;
                    }else{
                        Log.e("aaaa","요청 실패 :"+weatherRepo.getResult().getCode());
                        Log.e("aaaa","메시지 :"+weatherRepo.getResult().getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<WeatherRepo> call, Throwable t) {
                Log.e("aaaa","날씨정보 불러오기 실패 :" + t.getMessage() );
                Log.e("aaaa","요청 메시지 :"+call.request());
            }
        });


    }

}
