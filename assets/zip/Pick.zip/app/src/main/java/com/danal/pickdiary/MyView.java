package com.danal.pickdiary;

/**
 * Created by phkim on 2017-02-14.
 */

public interface MyView {
    void setResultText(String result);
}
