package com.test.androidmvpsample.mvp.main;

import android.util.Log;

import com.google.gson.JsonObject;
import com.test.androidmvpsample.retrofit.ApiCallback;
import com.test.androidmvpsample.mvp.other.BasePresenter;



public class MainPresenter extends BasePresenter<MainView> {

    public MainPresenter(MainView view) {
        attachView(view);
    }

    public void loadDataByRetrofitRxjava(String cityId) {
        mvpView.showLoading();
        JsonObject joBody = new JsonObject();
        try {
            joBody.addProperty("email", "phkim@aaa.com");
        } catch (Exception e) {

        }

        addSubscription(apiStores.loadDataByRetrofitRxjava(joBody),
                new ApiCallback<LoginModel>() {
                    @Override
                    public void onSuccess(LoginModel model) {
                        mvpView.getDataSuccess(model);
                    }

                    @Override
                    public void onFailure(Integer code,String msg) {
                        Log.d("test",code+"   "+msg);
                        mvpView.getDataFail(msg);
                    }


                    @Override
                    public void onFinish() {
                        mvpView.hideLoading();
                    }

                });
    }

}
