package com.test.androidmvpsample.mvp.main;


public interface MainView extends BaseView{

    void getDataSuccess(LoginModel model);

    void getDataFail(String msg);

}
