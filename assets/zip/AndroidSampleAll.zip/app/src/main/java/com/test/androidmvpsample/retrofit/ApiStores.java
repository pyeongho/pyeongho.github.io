package com.test.androidmvpsample.retrofit;

import com.google.gson.JsonObject;
import com.test.androidmvpsample.mvp.main.LoginModel;

import io.reactivex.Observable;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;



public interface ApiStores {
    //baseUrl
    String API_SERVER_URL = "https:/";

    //加载天气
    @Headers( "Content-Type: application/json" )
    @POST("account/login")
    Call<LoginModel> loadDataByRetrofit(@Body JsonObject body);


    @Headers( "Content-Type: application/json" )
    @POST("account/login")
    Observable<LoginModel> loadDataByRetrofitRxjava(
            @Body JsonObject body);
}
