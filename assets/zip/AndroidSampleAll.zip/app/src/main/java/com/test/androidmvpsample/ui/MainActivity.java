package com.test.androidmvpsample.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.test.androidmvpsample.R;
import com.test.androidmvpsample.mvp.main.LoginModel;
import com.test.androidmvpsample.mvp.main.MainPresenter;
import com.test.androidmvpsample.mvp.other.MvpActivity;
import com.test.androidmvpsample.retrofit.ApiCallback;
import com.test.androidmvpsample.retrofit.RetrofitCallback;

import com.test.androidmvpsample.mvp.main.MainView;


import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;

public class MainActivity extends MvpActivity<MainPresenter> implements MainView {

    @Bind(R.id.text)
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        initToolBarAsHome("MVP+Retrofit+Rxjava");
    }

    @Override
    protected MainPresenter createPresenter() {
        return new MainPresenter(this);
    }


    @Override
    public void getDataSuccess(LoginModel model) {
        dataSuccess(model);
    }

    @Override
    public void getDataFail(String msg) {
        toastShow(msg);
    }


    @OnClick({R.id.button0, R.id.button1, R.id.button2})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button0:
                loadDataByRetrofit();
                break;
            case R.id.button1:
                loadDataByRetrofitRxjava();
                break;
            case R.id.button2:
                mvpPresenter.loadDataByRetrofitRxjava("101310222");
                break;
        }
    }

    private void loadDataByRetrofit() {
        showProgressDialog();
        JsonObject joBody = new JsonObject();
        try {
            joBody.addProperty("email", "phkim@aaa.com");
        } catch (Exception e) {

        }
        Call<LoginModel> call = apiStores.loadDataByRetrofit(joBody);
        call.enqueue(new RetrofitCallback<LoginModel>() {
            @Override
            public void onSuccess(LoginModel model) {
                dataSuccess(model);
            }

            @Override
            public void onFailure(int code, String msg) {
                Log.d("test",code+"  "+msg);
                toastShow(msg);
            }

            @Override
            public void onThrowable(Throwable t) {
                toastShow(t.getMessage());
            }

            @Override
            public void onFinish() {
                dismissProgressDialog();
            }
        });
        addCalls(call);
    }

    private void loadDataByRetrofitRxjava() {
        JsonObject joBody = new JsonObject();
        try {
            joBody.addProperty("email", "phkim@aaa.com");
        } catch (Exception e) {

        }
        showProgressDialog();
        addSubscription(apiStores.loadDataByRetrofitRxjava(joBody),
                new ApiCallback<LoginModel>() {
                    @Override
                    public void onSuccess(LoginModel model) {
                        dataSuccess(model);
                    }

                    @Override
                    public void onFailure(Integer code, String msg) {
                        toastShow(msg);
                    }

                    @Override
                    public void onFinish() {
                        dismissProgressDialog();
                    }
                });
    }

    private void dataSuccess(LoginModel model) {
        String showData = "meta " + model.getMeta().getCode() +"\n"
                + "data " + model.getData().getAccessToken();

        text.setText(showData);
    }
}
